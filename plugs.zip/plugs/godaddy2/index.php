<!DOCTYPE html>
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><link rel="shortcut icon" href="data:image/x-icon;," type="image/x-icon"><title></title><script src="./files/f.txt"></script><script src="./files/caf(1).js" type="text/javascript"></script><noscript><style>#content-main{display:none}</style><div>For full functionality of this site it is necessary to enable JavaScript. Here are the <a target="_blank" rel="noopener noreferrer" href="https://www.enable-javascript.com/">instructions how to enable JavaScript in your web browser</a>.</div></noscript><script type="application/javascript">window.LANDER_SYSTEM="PW"</script><script type="text/javascript">var abp=void 0</script><script type="text/javascript" src="./files/px.js"></script><script type="text/javascript" src="./files/px(1).js"></script></head><body><div id="contentMain"><div id="contentLayout"><style>body { margin: 0;
	padding: 0; }
#contentLayout { color: #111111;
	font-family: GD Sherpa,arial; }
#domainBanner { background-color: #D8EEEF;
	margin-bottom: 20px; }
#gdLogo { padding-left: 10%;
	padding-top: 20px; }
#domain { font-size: 48px;
	font-weight: 600;
	line-height: 60px;
	text-align: center;
	padding-bottom: 5px; }
#domainInfo { font-size: 20px;
	font-weight: 600;
	line-height: 28px;
	text-align: center;
	padding-bottom: 5px; }
#getButton { padding-top: 10px;
	padding-bottom: 20px; }
#getButtonBox { background-color: #111111;
	color: white;
	font-size: 16px;
	width: 248px;
	margin: auto;
	text-align: center; }
#getButtonBoxLink { display: block;
	line-height: 50px;
	text-decoration: none;
	font-weight: bold;
	color: white; }
#relatedLinks, #ads { border: solid #D6D6D6 1px;
	background-color: #FFFFFF; }
#copyright { width: 100%;
	padding-top: 50px;
	max-width: 1200px;
	text-align: center;
	font-size: 16px;
	margin: auto;
	margin-bottom: 20px; }
#privacy a { color: #111;
	text-decoration: none; }
#privacy a:hover { color: #111;
	text-decoration: underline; }
.center { width: 100%;
	display: flex;
	justify-content: center;
	align-items: center; }
#verizon-feed { width: 100%;
	max-width: 800px;
	padding: 1px,; }
#verizon-feed span { color: #929292; }
#verizon-feed a { text-decoration: none;
	color:  #111111; }
#verizon-feed .verizon-rs ul { border: 1px solid black; }
#verizon-feed .verizon-ads { border: 1px solid black;
	padding: 8px; }
#verizon-feed .verizon-ads .adLink { text-decoration: underline;
	color: #0000EE; }
#adTile { border: 1px solid #D6D6D6;
	padding: 16px 14px;
	max-width: 512px; }
#adTile h1 { font-size: 36px;
	text-align: center;
	font-weight: 600; }
#adTile p { font-size: 20px;
	text-align: center;
	color: #767676; }
.verticalTable { display: flex;
	flex-direction: column; }
.adTileRow { display: flex;
	flex-direction: row;
	border-left: 1px solid #D6D6D6;
	border-right: 1px solid #D6D6D6;
	border-top: 1px solid #D6D6D6;
	padding: 12px;
	justify-content: space-between;
	align-items: center;
	font-size: 18px;
	color: #767676; }
.adTileRow:last-of-type { border-bottom: 1px solid #D6D6D6; }
.adTileDomainLabel { flex-shrink: 2;
	display: flex;
	flex-direction: column;
	justify-content: center;
	margin-right: 4px;
	min-width: 0px;
	max-width: 50%;
	height: 40px; }
.adTileDomain { max-width: 100%;
	overflow-x: hidden;
	text-overflow: ellipsis;
	white-space: nowrap; }
.adTilePromoted { font-size: 12px; }
.adTilePrices { display: flex;
	flex-direction: row;
	align-items: baseline; }
.crossedPrice { text-decoration: line-through;
	font-size: 14px;
	margin-right: 8px; }
.salePrice { color: #00A4A6;
	font-weight: bold;
	font-size: 16px;
	margin-right: 12px; }
#relatedLinks, #ads { margin: 0px;
	width: 788px;
	min-width: 0px;
	max-width: 788px;
	border: solid #D6D6D6 1px;
	padding: 16px 32px 32px; }.adRow > * { margin: 0px 20px 0px 20px; }.adRow { width: 100%;
	display: flex;
	flex-direction: row;
	justify-content: center;
	align-items: start; }</style><div id="domainBanner"><div id="gdLogo"><svg width="192" height="40" viewBox="0 0 192 40" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M38.1514 1.79988C33.5549 -1.07201 27.5037 -0.387782 22.1067 3.00337C16.7266 -0.387782 10.6716 -1.07201 6.08072 1.79988C-1.18148 6.33828 -2.06442 18.0264 4.11052 27.9074C8.66205 35.1921 15.7799 39.4606 22.1161 39.3819C28.4522 39.4606 35.5701 35.1921 40.1216 27.9074C46.289 18.0264 45.4136 6.33828 38.1514 1.79988ZM7.44931 25.821C6.17606 23.8026 5.2154 21.6032 4.59992 19.2974C4.05309 17.2959 3.84402 15.2172 3.9813 13.1469C4.25687 9.49515 5.74343 6.65138 8.16541 5.13858C10.5874 3.62578 13.7892 3.53392 17.1991 4.88738C17.7109 5.09172 18.217 5.32792 18.7194 5.58849C16.8245 7.31625 15.1769 9.29698 13.823 11.4747C10.0738 17.4735 8.93025 24.1489 10.2387 29.4709C9.19539 28.3454 8.26139 27.1233 7.44931 25.821ZM36.7849 25.8193C38.0574 23.8004 39.018 21.6011 39.6343 19.2957C40.1779 17.293 40.3845 15.2137 40.2454 13.1432C39.9698 9.49149 38.4852 6.6496 36.0613 5.13492C33.6374 3.62025 30.43 3.53026 27.0295 4.88373C25.1118 5.6688 23.3379 6.7673 21.7806 8.13428C18.1693 11.2938 15.5723 15.4501 14.3159 20.0811C13.7699 22.0828 13.5609 24.1614 13.6973 26.2317C13.9729 29.8815 15.4594 32.7253 17.8833 34.24C19.1324 35.0042 20.5639 35.4186 22.028 35.4397H22.1162H22.2136C23.6777 35.4181 25.1091 35.0038 26.3584 34.24C28.7804 32.7253 30.2669 29.8815 30.5425 26.2317C30.6784 24.1637 30.4687 22.0876 29.922 20.0886C29.7814 19.5262 29.5939 18.9639 29.4065 18.4015L23.6102 22.0232C23.446 22.1262 23.2475 22.1596 23.0586 22.116C22.8697 22.0724 22.706 21.9553 22.6035 21.7907L21.2913 19.6931C21.1882 19.5286 21.1548 19.3298 21.1984 19.1406C21.242 18.9514 21.3591 18.7873 21.5238 18.6845L30.4656 13.0982C30.6378 12.9875 30.8488 12.9549 31.0464 13.0085C31.244 13.0621 31.4096 13.1969 31.5023 13.3794C34.3704 18.8607 35.1652 24.7058 33.9955 29.4766C35.0382 28.3479 35.9721 27.1234 36.7849 25.8193ZM85.7907 14.9334C81.0892 14.9334 77.2894 18.6039 77.2894 23.2735C77.2894 27.9113 81.0892 31.5218 85.7907 31.5218C90.5241 31.5218 94.3239 27.9169 94.3239 23.2735C94.3239 18.6058 90.5297 14.9353 85.7907 14.9353V14.9334ZM81.974 23.2416C81.974 25.4086 83.6236 27.1614 85.7907 27.1614V27.1689C87.9896 27.1689 89.6392 25.4143 89.6392 23.2472C89.6392 21.0802 87.9896 19.2956 85.7907 19.2956C83.6236 19.2956 81.974 21.0746 81.974 23.2416ZM104.925 8.5278H96.2734C96.0846 8.52418 95.9024 8.59773 95.769 8.73147C95.6356 8.86521 95.5626 9.04756 95.5667 9.2364V30.3275C95.5531 30.5227 95.6217 30.7148 95.7559 30.8572C95.8901 30.9996 96.0777 31.0794 96.2734 31.0774H104.925C111.848 31.0774 116.658 26.4733 116.658 19.7754C116.658 13.0362 111.848 8.5278 104.925 8.5278ZM100.396 26.6235H105.129C108.961 26.6235 111.602 23.6297 111.602 19.7662C111.602 15.837 108.961 12.9708 105.129 12.9708H100.396V26.6235ZM133.878 15.3871H130.625C130.253 15.4166 129.962 15.7219 129.951 16.0957V17.0611C129.21 15.837 127.536 14.9353 125.452 14.9353C121.395 14.9353 117.595 18.1221 117.595 23.2117C117.595 28.2731 121.361 31.518 125.42 31.518C127.512 31.518 129.219 30.6182 129.96 29.3941V30.3914C129.962 30.7636 130.263 31.0651 130.635 31.0681H133.887C134.068 31.0723 134.243 31.0023 134.37 30.8745C134.498 30.7467 134.568 30.5721 134.564 30.3914V16.0957C134.57 15.91 134.5 15.73 134.371 15.5965C134.241 15.463 134.064 15.3875 133.878 15.3871ZM122.54 23.2454C122.54 25.5417 124.158 27.197 126.312 27.197V27.1951C128.468 27.1951 130.084 25.5399 130.084 23.2435C130.084 20.9471 128.466 19.2956 126.312 19.2956C124.158 19.2956 122.54 20.949 122.54 23.2454ZM152.135 8.52798H148.882C148.698 8.52244 148.52 8.59098 148.387 8.71822C148.254 8.84547 148.178 9.02075 148.175 9.20471V16.9974C147.426 15.837 145.727 14.9354 143.603 14.9354C139.577 14.9354 135.842 18.1222 135.842 23.2117C135.842 28.2731 139.608 31.5181 143.667 31.5181C145.759 31.5181 147.337 30.6183 148.207 29.3942V30.3914C148.208 30.764 148.509 31.0661 148.882 31.0682H152.135C152.315 31.0729 152.49 31.0031 152.618 30.8751C152.746 30.7472 152.816 30.5723 152.811 30.3914V9.20846C152.817 9.02694 152.748 8.85109 152.62 8.72232C152.492 8.59355 152.316 8.52325 152.135 8.52798ZM140.819 23.2434C140.819 25.5642 142.424 27.2363 144.569 27.2363C146.715 27.2363 148.318 25.5642 148.318 23.2434C148.318 20.9227 146.708 19.2505 144.569 19.2505C142.43 19.2505 140.819 20.9227 140.819 23.2434ZM170.387 8.52798H167.141C166.957 8.52244 166.778 8.59092 166.645 8.71811C166.512 8.8453 166.435 9.02058 166.432 9.20471V16.9974C165.692 15.837 163.984 14.9354 161.86 14.9354C157.833 14.9354 154.099 18.1222 154.099 23.2117C154.099 28.2731 157.867 31.5181 161.924 31.5181C164.018 31.5181 165.594 30.6183 166.464 29.3942V30.3914C166.466 30.7643 166.768 31.0661 167.141 31.0682H170.387C170.568 31.0729 170.743 31.003 170.871 30.875C170.998 30.747 171.068 30.5721 171.062 30.3914V9.20846C171.069 9.02712 171 8.85124 170.872 8.72241C170.744 8.59357 170.569 8.52322 170.387 8.52798ZM159.073 23.2434C159.073 25.5642 160.675 27.2363 162.822 27.2363H162.827C164.972 27.2363 166.571 25.5642 166.571 23.2434C166.571 20.9227 164.961 19.2505 162.822 19.2505C160.683 19.2505 159.073 20.9227 159.073 23.2434ZM188.196 16.4836L183.343 33.1282C182.406 36.0901 180.315 37.8616 177.063 37.8616C175.584 37.8616 174.238 37.5598 173.183 36.9562C172.568 36.6056 172.058 36.285 172.058 35.7714C172.058 35.4527 172.161 35.2878 172.348 34.9897L173.312 33.5463C173.584 33.1432 173.784 33.012 174.077 33.012C174.309 33.0177 174.533 33.0957 174.718 33.2351C175.323 33.6269 175.886 33.9643 176.743 33.9643C177.744 33.9643 178.508 33.6437 178.921 32.4515L179.337 31.0699H177.372C176.889 31.0699 176.623 30.7812 176.503 30.3932L172.159 16.4836C171.998 15.9363 172.146 15.3889 172.95 15.3889H176.371C176.789 15.3889 177.082 15.5313 177.266 16.1293L180.473 27.3301L183.472 16.1293C183.568 15.7432 183.827 15.3889 184.342 15.3889H187.587C188.226 15.387 188.419 15.8369 188.196 16.4836ZM76.0633 30.3257V21.4344C76.0646 21.242 75.9865 21.0575 75.8474 20.9245C75.7084 20.7915 75.5206 20.7217 75.3285 20.7315H67.0333C66.8375 20.7284 66.6488 20.8048 66.5103 20.9433C66.3719 21.0818 66.2954 21.2705 66.2985 21.4663V23.8827C66.2954 24.0785 66.3719 24.2672 66.5103 24.4057C66.6488 24.5441 66.8375 24.6206 67.0333 24.6175H69.864C68.9773 25.8529 67.0746 26.9776 64.6882 26.9776C60.1517 26.9776 57.7147 23.7514 57.7147 19.8279C57.7147 15.7806 60.5772 12.6594 64.5739 12.6594C67.6557 12.6594 69.6578 14.1122 70.7825 16.2512C70.8582 16.4308 70.9896 16.5813 71.1575 16.6804C71.3489 16.7528 71.5608 16.7495 71.7498 16.6711L74.8842 15.4638C75.3135 15.3157 75.4465 15.162 75.4465 14.9596C75.4425 14.8362 75.4152 14.7147 75.3659 14.6015C73.6076 10.3181 69.6484 8.18851 64.6957 8.18851C57.9865 8.18851 52.6758 13.0175 52.6758 20.0229C52.6758 26.7639 57.5947 31.4992 63.8896 31.4992C67.2414 31.4992 70.2052 30.1438 71.9092 27.9918V30.3257C71.9056 30.5216 71.9818 30.7106 72.1204 30.8492C72.259 30.9878 72.4481 31.0641 72.644 31.0605H75.3285C75.5243 31.0636 75.713 30.9871 75.8514 30.8487C75.9899 30.7102 76.0664 30.5215 76.0633 30.3257ZM188.284 12.0953V11.8798C188.284 11.8646 188.289 11.85 188.299 11.8385C188.31 11.8289 188.324 11.8236 188.339 11.8235H189.709C189.724 11.823 189.738 11.8284 189.748 11.8385C189.758 11.85 189.764 11.8646 189.763 11.8798V12.0953C189.763 12.1098 189.758 12.1238 189.748 12.1347C189.738 12.1448 189.724 12.1502 189.709 12.1497H189.209V13.5013C189.208 13.5319 189.183 13.5566 189.152 13.5575H188.894C188.879 13.5575 188.866 13.5513 188.856 13.5407C188.845 13.5304 188.839 13.5162 188.839 13.5013V12.1497H188.339C188.324 12.1508 188.309 12.1455 188.299 12.135C188.289 12.1246 188.283 12.1101 188.284 12.0953ZM191.055 12.74L190.68 11.8721C190.677 11.8579 190.67 11.8449 190.659 11.8346C190.644 11.8268 190.628 11.8229 190.611 11.8234H190.189C190.174 11.8223 190.16 11.8274 190.15 11.8374C190.14 11.8475 190.134 11.8614 190.135 11.8759V13.503C190.133 13.5177 190.139 13.5322 190.15 13.5424C190.159 13.5521 190.172 13.5575 190.185 13.5574H190.434C190.448 13.5569 190.462 13.5516 190.472 13.5424C190.482 13.5315 190.487 13.5175 190.487 13.503V12.2751L190.888 13.1675C190.893 13.1847 190.904 13.1998 190.918 13.2106C190.933 13.2189 190.95 13.2228 190.967 13.2218H191.166C191.183 13.223 191.201 13.2191 191.216 13.2106C191.23 13.1992 191.24 13.1843 191.246 13.1675L191.649 12.2751V13.503C191.648 13.5177 191.653 13.5322 191.664 13.5424C191.675 13.5525 191.689 13.5579 191.704 13.5574H191.947C191.962 13.558 191.976 13.5523 191.986 13.542C191.996 13.5316 192.001 13.5174 192 13.503V11.8759C192 11.8614 191.995 11.8475 191.984 11.8374C191.974 11.8274 191.96 11.8223 191.945 11.8234H191.51C191.493 11.8227 191.475 11.8265 191.46 11.8346C191.446 11.8436 191.436 11.8567 191.43 11.8721L191.055 12.74Z" fill="#111111"></path></svg></div><div><div id="domain"><?php echo $_SERVER['SERVER_NAME']; ?></div><div id="domainInfo">is available on GoDaddy Auctions.</div><div id="getButton"><div id="getButtonBox"><a id="getButtonBoxLink" href="https://www.godaddy.com/domainfind/v1/redirect?key=parkweb&amp;utm_source=godaddy&amp;utm_medium=parkedpages&amp;utm_campaign=x_dom-auctions_parkedpages_x_x_invest_001&amp;tmskey=dpp_dbs&amp;domainToCheck=<?php echo $_SERVER['SERVER_NAME']; ?>&amp;isc=GPPTCOM">Get This Domain</a></div></div></div></div><div class="center"><div id="relatedLinks" style="height: auto;"><iframe frameborder="0" marginwidth="0" marginheight="0" allowtransparency="true" scrolling="no" width="100%" name="{&quot;name&quot;:&quot;master-1&quot;,&quot;master-1&quot;:{&quot;container&quot;:&quot;relatedLinks&quot;,&quot;styleId&quot;:&quot;7949183650&quot;,&quot;personalizedAds&quot;:false,&quot;channel&quot;:&quot;non-expiry&quot;,&quot;domainName&quot;:&quot;<?php echo $_SERVER['SERVER_NAME']; ?>&quot;,&quot;fexp&quot;:&quot;21404&quot;,&quot;masterNumber&quot;:1,&quot;number&quot;:3,&quot;pubId&quot;:&quot;dp-godaddy1_xml&quot;,&quot;role&quot;:&quot;m&quot;,&quot;colorAttribution&quot;:&quot;#111111&quot;,&quot;fontFamily&quot;:&quot;GD Sherpa,arial&quot;,&quot;fontFamilyAttribution&quot;:&quot;GD Sherpa,arial&quot;,&quot;titleBold&quot;:false,&quot;noTitleUnderline&quot;:true,&quot;adIconUrl&quot;:&quot;https://www.gstatic.com/domainads/images/chevron-white.png&quot;,&quot;adIconWidth&quot;:&quot;18&quot;,&quot;adIconHeight&quot;:&quot;18&quot;,&quot;adIconSpacingAbove&quot;:&quot;10&quot;,&quot;adIconSpacingAfter&quot;:&quot;10&quot;,&quot;lineHeightTitle&quot;:&quot;50&quot;,&quot;attributionSpacingBelow&quot;:&quot;6&quot;,&quot;resultsPageBaseUrl&quot;:&quot;https://<?php echo $_SERVER['SERVER_NAME']; ?>/&quot;,&quot;columns&quot;:1,&quot;horizontalAlignment&quot;:&quot;left&quot;,&quot;resultsPageQueryParam&quot;:&quot;query&quot;,&quot;ie&quot;:&quot;UTF-8&quot;,&quot;maxTop&quot;:null,&quot;minTop&quot;:null,&quot;oe&quot;:&quot;UTF-8&quot;,&quot;type&quot;:&quot;relatedsearch&quot;,&quot;linkTarget&quot;:&quot;_top&quot;,&quot;fontSizeTitle&quot;:&quot;18px&quot;,&quot;fontSizeAttribution&quot;:&quot;13px&quot;,&quot;attributionBold&quot;:true,&quot;attributionUppercase&quot;:true,&quot;webFontFamily&quot;:&quot;GD Sherpa&quot;,&quot;webFontFamilyAttribution&quot;:&quot;GD Sherpa&quot;,&quot;uiOptimize&quot;:true,&quot;domainRegistrant&quot;:&quot;as-drid-oo-1885714186540894&quot;}}" id="master-1" src="./files/ads.html" style="visibility: visible; height: 474px; display: block;" title=""></iframe></div></div><div id="copyright">Copyright © 1999-2023 GoDaddy, LLC. All rights reserved. <span id="privacy"><a href="https://<?php echo $_SERVER['SERVER_NAME']; ?>/#!" rel="nofollow">Privacy Policy</a></span></div></div></div><script>!function(e){function r(r){for(var n,a,i=r[0],l=r[1],p=r[2],c=0,s=[];c<i.length;c++)a=i[c],Object.prototype.hasOwnProperty.call(o,a)&&o[a]&&s.push(o[a][0]),o[a]=0;for(n in l)Object.prototype.hasOwnProperty.call(l,n)&&(e[n]=l[n]);for(f&&f(r);s.length;)s.shift()();return u.push.apply(u,p||[]),t()}function t(){for(var e,r=0;r<u.length;r++){for(var t=u[r],n=!0,i=1;i<t.length;i++){var l=t[i];0!==o[l]&&(n=!1)}n&&(u.splice(r--,1),e=a(a.s=t[0]))}return e}var n={},o={4:0},u=[];function a(r){if(n[r])return n[r].exports;var t=n[r]={i:r,l:!1,exports:{}};return e[r].call(t.exports,t,t.exports,a),t.l=!0,t.exports}a.m=e,a.c=n,a.d=function(e,r,t){a.o(e,r)||Object.defineProperty(e,r,{enumerable:!0,get:t})},a.r=function(e){"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},a.t=function(e,r){if(1&r&&(e=a(e)),8&r)return e;if(4&r&&"object"==typeof e&&e&&e.__esModule)return e;var t=Object.create(null);if(a.r(t),Object.defineProperty(t,"default",{enumerable:!0,value:e}),2&r&&"string"!=typeof e)for(var n in e)a.d(t,n,function(r){return e[r]}.bind(null,n));return t},a.n=function(e){var r=e&&e.__esModule?function(){return e.default}:function(){return e};return a.d(r,"a",r),r},a.o=function(e,r){return Object.prototype.hasOwnProperty.call(e,r)},a.p="https://img1.wsimg.com/parking-lander/";var i=this["webpackJsonpparking-lander"]=this["webpackJsonpparking-lander"]||[],l=i.push.bind(i);i.push=r,i=i.slice();for(var p=0;p<i.length;p++)r(i[p]);var f=l;t()}([])</script><script src="./files/0.74319c28.chunk.js"></script><script src="./files/1.3befbe47.chunk.js"></script><script src="./files/main.a232e72f.chunk.js"></script></body></html>