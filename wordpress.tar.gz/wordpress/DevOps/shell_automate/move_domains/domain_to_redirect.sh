#!/bin/sh

OLD_DOMAIN=$1
NEW_DOMAIN=$2
IS_PAGE_TO_PAGE=$3
NGINX_ROOT="/etc/nginx"
NGINX_SITES_AVAILABLE_DIR="/etc/nginx/sites-available"
NGINX_SITES_ENABLED_DIR="/etc/nginx/sites-enabled"
ALLOWED_REFERERS_FILE=$NGINX_ROOT/conf.d/allowed_referer

OLD_DOMAIN_A_NGINX="$NGINX_SITES_AVAILABLE_DIR/$OLD_DOMAIN.conf"
OLD_DOMAIN_E_NGINX="$NGINX_SITES_ENABLED_DIR/$OLD_DOMAIN.conf"

if [ -f $OLD_DOMAIN_A_NGINX ]; then
    echo -e "NGINX setting for the old domain $OLD_DOMAIN exists. Will delete files:\n$OLD_DOMAIN_A_NGINX\n$OLD_DOMAIN_E_NGINX"
    rm -f $OLD_DOMAIN_A_NGINX >/dev/null 2>&1
    rm -f $OLD_DOMAIN_E_NGINX >/dev/null 2>&1
fi

if [ ! -f $OLD_DOMAIN_NGINX ]; then
    echo -e "NGINX setting for the old domain $OLD_DOMAIN deleted."
fi

if [ $IS_PAGE_TO_PAGE == "main" ]; then
    echo "Create page to page redirect to the new domain $NEW_DOMAIN"
    sed -e "s/server_domain_or_IP/$OLD_DOMAIN/g" -e "s/redirect_domain_or_IP/$NEW_DOMAIN/g" /etc/nginx/conf.d/default_redirect >> /etc/nginx/sites-available/redirect_2.conf
fi

if [ $IS_PAGE_TO_PAGE == "page" ]; then
    echo "Create redirect to the main page for the new domain $NEW_DOMAIN"
    sed -e "s/server_domain_or_IP/$OLD_DOMAIN/g" -e "s/redirect_domain_or_IP/$NEW_DOMAIN/g" /etc/nginx/conf.d/page_to_page_redirect >> /etc/nginx/sites-available/redirect_2.conf
fi

echo "Restarting nginx..."
sudo nginx -t && sudo systemctl reload nginx
