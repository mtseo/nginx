#!/bin/sh

DOMAIN_NAME=$1
IS_GOOGLE_USER_VERSION_DIFFERENT=$2
ACCESS_TO_DIRECT_TRAFFIC=$3
SITES_PARENT_ROOT=/var/www/single_sites

USERS_ROOT="$SITES_PARENT_ROOT/$DOMAIN_NAME/www-users"
MAIN_ROOT="$SITES_PARENT_ROOT/$DOMAIN_NAME/www-google"
DOMAIN_ROOT="$SITES_PARENT_ROOT/$DOMAIN_NAME"

if [ $IS_GOOGLE_USER_VERSION_DIFFERENT == "false" ]; then
    MAIN_ROOT="$SITES_PARENT_ROOT/$DOMAIN_NAME"
fi

HOME_ROOT=$(pwd)
REPO_ROOT=$(git rev-parse --show-toplevel)

# nginx configs

NGINX_ROOT=/etc/nginx
DOMAINS_CONFIGS=$NGINX_ROOT/sites-available
DOMAINS_CONFIGS_LINKS=$NGINX_ROOT/sites-enabled
ALLOWED_REFERERS_FILE=$NGINX_ROOT/conf.d/allowed_referer

checkIfDirExist() {
    dir=$1
    if [ -d $dir ]; then
        echo >&2 "Directory $dir exists."
        retval="true"
    else
        echo >&2 "Directory $dir does not exists."
        retval="false"
    fi
    echo "$retval"
}

checkIfFileExist() {
    file=$1
    if [ -f $file ]; then
        echo >&2 "File $file exists."
        retval="true"
    else
        echo >&2 "File $file does not exists."
        retval="false"
    fi
    echo "$retval"
}

random (){
    if (( RANDOM %2 )); then
        echo 0
    else
        echo 1
    fi
}

random_number=$(random)

case $random_number in 
    0) RETURN_TO_PLUG="http://localhost:503;";;
    1) RETURN_TO_PLUG="http://localhost:505;";;
esac

check_domain_exist=$( checkIfDirExist "$SITES_PARENT_ROOT/$DOMAIN_NAME" )

if [ $check_domain_exist == "false" ]; then
    mkdir -p $MAIN_ROOT
    if [ $IS_GOOGLE_USER_VERSION_DIFFERENT == "true" ]; then
        mkdir -p $USERS_ROOT
    fi
fi

create_nginx() {
    if [ $(checkIfFileExist "$DOMAINS_CONFIGS/$DOMAIN_NAME.conf") ]; then
        echo "Nginx config for the domain $DOMAIN_NAME exists."
        # exit 1
    else
        touch $DOMAINS_CONFIGS/$DOMAIN_NAME.conf
        ln -s $DOMAINS_CONFIGS/$DOMAIN_NAME.conf $DOMAINS_CONFIGS_LINKS/$DOMAIN_NAME.conf >/dev/null 2>&1
    fi
}
  
repeatChar() {
    local input="$1"
    local count="$2"
    printf -v myString '%*s' "$count"
    printf '%s\n' "${myString// /$input}"
}

ind1=$(repeatChar " " 4)
ind2=$(repeatChar " " 8)
ind3=$(repeatChar " " 16)

fillNginxConfig() {
    nginx_config=$1
    
    # Create redirect from HTTP to HTTPS
    sed "s/server_domain/$DOMAIN_NAME/g" $REPO_ROOT/shell_automate/initial_conf/redirect_to_scheme > $nginx_config

    # Create redirect from WWW to NON-WWW
    sed "s/server_domain/$DOMAIN_NAME/g" $REPO_ROOT/shell_automate/initial_conf/redirect_to_domain >> $nginx_config

    # START FILLING GENERAL CONFIG

    echo -e "\nserver {" >> $nginx_config
    echo -e "$ind1""include /etc/nginx/load-balancer.conf;\n$ind1""server_name $DOMAIN_NAME;" >> $nginx_config
    echo -e "$ind1""set \$users_root_path \"$MAIN_ROOT\";" >> $nginx_config

    if [ $IS_GOOGLE_USER_VERSION_DIFFERENT == "true" ]; then
        echo -e "$ind1""if ( \$is_google = 0 ) {\n$ind2""set \$users_root_path \"$USERS_ROOT\";\n$ind1}" >> $nginx_config
    fi

    # Fill base html config
    sed "s/server_domain/$DOMAIN_NAME/g" $REPO_ROOT/shell_automate/initial_conf/html_site_conf >> $nginx_config

    echo -e "\n\n$ind1""location / {" >> $nginx_config
    if [ $ACCESS_TO_DIRECT_TRAFFIC == "true" ]; then
        echo -e "\n$ind2""proxy_set_header Host \$host;""\n$ind2""if ( \$allowed = 0 ) {\n""$ind3""proxy_pass $RETURN_TO_PLUG\n$ind2}" >> $nginx_config
    fi
    echo -e "$ind2""try_files \$uri \$uri/ /index.html?\$args =404;" >> $nginx_config
    echo -e "$ind1""}" >> $nginx_config
    sed "s/server_domain/$DOMAIN_NAME/g" $REPO_ROOT/shell_automate/initial_conf/html_site_end >> $nginx_config

    # Add domain to map rules
    formatted_string="\"~$DOMAIN_NAME\""
    printf '%-27.40s 1;\n' $formatted_string >> /etc/nginx/conf.d/allowed_referer
}

create_nginx

fillNginxConfig $DOMAINS_CONFIGS/$DOMAIN_NAME.conf
ln -s $DOMAINS_CONFIGS/$DOMAIN_NAME.conf $DOMAINS_CONFIGS_LINKS/$DOMAIN_NAME.conf >/dev/null 2>&1

if [ $IS_GOOGLE_USER_VERSION_DIFFERENT == "true" ]; then
    echo "Document root for google sites: $MAIN_ROOT"
    echo "Document root for user sites: $USERS_ROOT"
fi

cd $SITES_PARENT_ROOT
sudo chown -R wordpress:wordpress .
setfacl -R -m user:nginx:rwx,d:user:nginx:rwx .
cd $HOME_ROOT

echo "Nginx config here: $DOMAINS_CONFIGS/$DOMAIN_NAME.conf"

echo "Creating ssl certs..."
certbot certonly --nginx -d $DOMAIN_NAME -d www.$DOMAIN_NAME >/dev/null 2>&1

if [ ! -f /etc/letsencrypt/live/$DOMAIN_NAME/cert.pem ]; then
    echo "SSL certificates was not created. Please target the domain $DOMAIN_NAME to the ip: 64.226.106.234"
fi

if [ -f /etc/letsencrypt/live/$DOMAIN_NAME/cert.pem ]; then
    echo "Uncomment SSL settings in nginx config..."
    sed -i '/ssl_certificate/s/#//g' $DOMAINS_CONFIGS/$DOMAIN_NAME.conf
fi

echo "Restarting nginx..."
sudo nginx -t && sudo systemctl reload nginx
