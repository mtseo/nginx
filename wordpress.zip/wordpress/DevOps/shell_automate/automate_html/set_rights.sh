#! /bin/bash

domain=$1

DOMAIN_NAME=$1
SITES_PARENT_ROOT=/var/www/single_sites
USERS_ROOT="$SITES_PARENT_ROOT/$DOMAIN_NAME"
HOME_DIR=$(pwd)

if [ -d $USERS_ROOT ]; then
    cd $USERS_ROOT
    sudo chown -R wordpress:wordpress .
    setfacl -R -m user:nginx:rwx,d:user:nginx:rwx .
fi

