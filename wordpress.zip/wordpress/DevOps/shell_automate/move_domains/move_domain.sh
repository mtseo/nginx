#!/bin/sh

OLD_DOMAIN=$1
NEW_DOMAIN=$2
NGINX_SITES_AVAILABLE_DIR="/etc/nginx/sites-available"
NGINX_SITES_ENABLED_DIR="/etc/nginx/sites-enabled"
ALLOWED_REFERERS_FILE=$NGINX_ROOT/conf.d/allowed_referer

SITES_PARENT_ROOT=/var/www/single_sites
OLD_DOMAIN_NGINX="$NGINX_SITES_AVAILABLE_DIR/$OLD_DOMAIN.conf"
NEW_DOMAIN_NGINX="$NGINX_SITES_AVAILABLE_DIR/$NEW_DOMAIN.conf"

# Add domain to map rules
formatted_string="\"~$DOMAIN_NAME\""
printf '%-27.40s 1;\n' $formatted_string >> $ALLOWED_REFERERS_FILE

if [ ! -f /etc/letsencrypt/live/$NEW_DOMAIN/cert.pem ]; then
    echo "SSL certificate doesn't exist."
    echo "Creating ssl certs..."
    certbot certonly --nginx -d $NEW_DOMAIN -d www.$NEW_DOMAIN > certbot_results
fi

if [ ! -f /etc/letsencrypt/live/$NEW_DOMAIN/cert.pem ]; then
    echo "SSL certificates was not created. Please target the domain $DOMAIN_NAME to the ip: 134.122.70.161 or find out the error in the file:"
    cat certbot_results
fi

if [ -f $OLD_DOMAIN_NGINX ]; then
    echo "$OLD_DOMAIN_NGINX exist. Will move to $NEW_DOMAIN_NGINX"
    sed "s/$OLD_DOMAIN/$NEW_DOMAIN/g" $OLD_DOMAIN_NGINX > $NEW_DOMAIN_NGINX
    ln -s $NEW_DOMAIN_NGINX $NGINX_SITES_ENABLED_DIR/$NEW_DOMAIN.conf >/dev/null 2>&1
    if [ ! -f /etc/letsencrypt/live/$NEW_DOMAIN/cert.pem ]; then
        sudo sed -i '/ssl_certificate/s//#ssl_certificate/g' $NEW_DOMAIN_NGINX
    fi
fi

# Add domain to map rules
formatted_string="\"~$DOMAIN_NAME\""
printf '%-27.40s 1;\n' $formatted_string >> /etc/nginx/conf.d/allowed_referer

OLD_DIRECTORY=$SITES_PARENT_ROOT/$OLD_DOMAIN
NEW_DIRECTORY=$SITES_PARENT_ROOT/$NEW_DOMAIN

mkdir -p $NEW_DIRECTORY
echo "Copying files from $OLD_DIRECTORY to the new directory $NEW_DIRECTORY..."

cp -Rf $OLD_DIRECTORY/* $NEW_DIRECTORY >/dev/null 2>&1

if [ ! -f /etc/letsencrypt/live/$DOMAIN_NAME/cert.pem ]; then
    echo "SSL certificates was not created. Please target the domain $NEW_DOMAIN to the ip: 64.226.106.234"
fi

echo "Restarting nginx..."
sudo nginx -t && sudo systemctl reload nginx

# echo "Search - replace domains in the database"

# if [ -f $NEW_DIRECTORY/wp-config.php ]; then
#     DB_NAME=$(sed -n "s/define( *'DB_NAME', *'\([^']*\)'.*/\1/p" $NEW_DIRECTORY/wp-config.php)
#     DB_USER=$(sed -n "s/define( *'DB_USER', *'\([^']*\)'.*/\1/p" $NEW_DIRECTORY/wp-config.php)
#     DB_PASSWORD=$(sed -n "s/define( *'DB_PASSWORD', *'\([^']*\)'.*/\1/p" $NEW_DIRECTORY/wp-config.php)
#     DB_HOST=$(sed -n "s/define( *'DB_HOST', *'\([^']*\)'.*/\1/p" $NEW_DIRECTORY/wp-config.php | cut -d ":" -f1)
# fi

# echo $DB_HOST
# echo $DB_NAME
# mysql -h $DB_HOST -P 25060 --password="AVNS_TLSIjHuMCa7gsmuwIww" -u doadmin $DB_NAME --execute="UPDATE wp_options SET option_value = replace(option_value, '$OLD_DOMAIN', '$NEW_DOMAIN') WHERE option_name = 'home' OR option_name = 'siteurl';"
# mysql -h $DB_HOST -P 25060 --password="AVNS_TLSIjHuMCa7gsmuwIww" -u doadmin $DB_NAME --execute="UPDATE wp_posts SET guid = replace(guid, '$OLD_DOMAIN','$NEW_DOMAIN');"
# mysql -h $DB_HOST -P 25060 --password="AVNS_TLSIjHuMCa7gsmuwIww" -u doadmin $DB_NAME --execute="UPDATE wp_posts SET post_content = replace(post_content, '$OLD_DOMAIN', '$NEW_DOMAIN');"
# mysql -h $DB_HOST -P 25060 --password="AVNS_TLSIjHuMCa7gsmuwIww" -u doadmin $DB_NAME --execute="UPDATE wp_postmeta SET meta_value = replace(meta_value, '$OLD_DOMAIN', '$NEW_DOMAIN');"

